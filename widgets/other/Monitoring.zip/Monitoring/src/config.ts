export interface UserInfo {
    username: string,
    fullName: string,
    lastLogin: number,
    created: number,
    role: string
}