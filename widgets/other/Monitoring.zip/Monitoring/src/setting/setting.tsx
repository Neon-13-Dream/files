/** @jsx jsx */
import {
    React, jsx, Immutable,
    DataSourceTypes
} from 'jimu-core'
import { TextInput } from 'jimu-ui';

import type { AllWidgetSettingProps } from 'jimu-for-builder'
import { DataSourceSelector } from 'jimu-ui/advanced/data-source-selector'

export default function Setting(props: AllWidgetSettingProps<any>) {
    const { id, config, onSettingChange } = props
    const saveHandler = (useDataSources: any[]) => {
        props.onSettingChange({
            id: id,
            useDataSources: useDataSources
        })
    }

    const handleTextChange = (value: string) => {
        onSettingChange({
            id,
            config: config.set('portalName', value)
        });
    };

    return (
        <div style={{
            display: 'flex',
            flexDirection: 'column',
            padding: "15px",
            gap: '10px'
        }}>
            <DataSourceSelector
                mustUseDataSource
                types={Immutable([DataSourceTypes.FeatureLayer])}
                useDataSources={props.useDataSources}
                onChange={saveHandler}
                widgetId={id}
            />
            <div style={{
                marginTop: "5px",
                marginBottom: "-5px"
            }}>
                Введите название приложения
            </div>
            <TextInput
                size="default"
                type="text"
                value={config.portalName || ''}
                onChange={(e: any) => handleTextChange(e.target.value)}
                placeholder="   Введите название"
                maxLength={200}
                title="Поле чтобы указать название текущего приложения если он будет пустым то название берётся автоматически с самого приложения"
            />
        </div>
    )
}
