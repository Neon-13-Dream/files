/** @jsx jsx */
import {
    React, jsx, DataSourceComponent,
    AllWidgetProps, getAppStore
} from 'jimu-core'
import { loadArcGISJSAPIModules } from 'jimu-arcgis'

export default function Widget(props: AllWidgetProps<any>) {
    const {
        username, fullName,
        lastLogin, role,
        created
    } = props.user

    const {
        // name, title,
        id, type, owner
    } = getAppStore().getState().appInfo || {}

    const useDataSource = props.useDataSources?.[0]
    const featureLayer = React.useRef<any>(null)
    const [isReady, setReady] = React.useState(false)
    const today = new Date()

    const curData = React.useRef({
        durationint: 0
    })

    // const timeOut = React.useRef<any>(null)
    const timer = React.useRef<any>(null)
    const updateTimer = React.useRef<any>(null)

    const isInitializing = React.useRef(false)
    const isMountedRef = React.useRef(true)

    var addTime = 1

    const waitForAppInfo = async (timeoutMs = 5000, intervalMs = 100) => {
        const start = Date.now()
        while (Date.now() - start < timeoutMs) {
            const appInfo = getAppStore().getState().appInfo
            if (appInfo && Object.keys(appInfo).length) return appInfo
            await new Promise(r => setTimeout(r, intervalMs))
        }
        return getAppStore().getState().appInfo
    }

    const findExistingRecord = async (ds: any, portalNameVal: string, usernameVal: string) => {
        const result = await ds.query({
            where: `portalname = '${portalNameVal}' AND username = '${usernameVal}' AND datestr LIKE '${today.toLocaleDateString('ru-RU')}%'`,
            outFields: ['objectid', 'dateinint', 'dateinstr', 'lastactint', 'lastactstr', 'durationint'],
            returnGeometry: true,
            orderByFields: ['lastactint DESC', 'dateinint DESC']
        })
        if (result && result.records && result.records.length) {
            return result.records[0].getData()
        }
        return null
    }

    const addNewFeatures = async (ds: any, portalNameVal: string) => {
        if (!featureLayer.current) {
            // console.warn('⚠️ featureLayer ещё не инициализирован — addNewFeatures пропущен')
            return
        }

        const existing = await findExistingRecord(ds, portalNameVal, username)
        if (existing) {
            // console.log('Запись уже существует — пропускаем addNewFeatures')
            curData.current = { ...existing }
            return existing.objectid || null
        }

        const now = new Date(lastLogin)

        // начало сегодняшнего дня
        const startOfDay = new Date(
            now.getFullYear(),
            now.getMonth(),
            now.getDate()
        );

        // дата в секундах без времени
        const dateint = Math.floor(startOfDay.getTime() / 1000);

        // время в секундах от начала суток
        const timeint = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();

        // дата и время полностью (сек)
        const dateinint = Math.floor(now.getTime() / 1000);

        // created
        const createdDate = new Date(created);
        const createdint = Math.floor(createdDate.getTime() / 1000);

        const result = await featureLayer.current.applyEdits({
            addFeatures: [{
                geometry: {
                    type: 'point',
                    x: 0,
                    y: 0,
                    spatialReference: { wkid: 4326 }
                },
                attributes: {
                    portalname: portalNameVal,
                    username: username,
                    fullname: fullName || '',
                    datestr: now.toLocaleDateString('ru-RU'),
                    dateint: dateint,
                    timestr: now.toLocaleTimeString('ru-RU'),
                    timeint: timeint,
                    dateinstr: today.toLocaleString('ru-RU'),
                    dateinint: dateinint,
                    lastactstr: today.toLocaleString('ru-RU'),
                    lastactint: dateinint,
                    durationint: curData.current.durationint,
                    durationstr: `${curData.current.durationint}`,
                    role: role || 'custom',
                    createdstr: createdDate.toLocaleString('ru-RU'),
                    createdint: createdint,
                    portaltype: type,
                    portalid: id,
                    portalowner: owner
                }
            }]
        })

        const addResult = result?.addFeatureResults?.[0]
        if (addResult?.error) throw new Error(addResult.error.message)
        // console.log('✅ Добавлена новая запись пользователя')
        return addResult?.objectId || null
    }

    const dataSourceCreated = async (ds: any) => {
        if (isInitializing.current) {
            // console.log('Инициализация уже выполняется — пропускаем дублирующий вызов')
            return
        }
        isInitializing.current = true

        const appInfo = await waitForAppInfo(5000, 100)
        const portalNameVal = props.config.portalName || appInfo?.name || appInfo?.title || 'unknown_portal'

        const [FeatureLayerObj] = await loadArcGISJSAPIModules(['esri/layers/FeatureLayer'])
        const url = ds.getUrl?.() || ds.url
        if (!url) throw new Error('URL слоя не найден')

        featureLayer.current = new FeatureLayerObj({ url })

        const existing = await findExistingRecord(ds, portalNameVal, username)
        if (existing) {
            // console.log('👤 Пользователь найден (после дополнительной проверки)')
            curData.current = { ...existing }
            curData.current.dateinstr = new Date().toLocaleString('ru-RU')
            curData.current.dateinint = Math.floor(Date.now() / 1000)

            if (featureLayer.current) {
                await featureLayer.current.applyEdits({
                    updateFeatures: [{ attributes: curData.current }]
                })
            }
        } else {
            // console.log('🆕 Новый пользователь (после проверки) — создаём запись')
            await addNewFeatures(ds, portalNameVal)
        }

        setReady(true)

        isInitializing.current = false
    }

    React.useEffect(() => {
        // if (navigator.geolocation) {
        //     console.log(navigator)
        //     console.log(navigator.geolocation)            
        //     navigator.geolocation.getCurrentPosition(
        //         (position) => {
        //             console.log("Широта:", position);
        //             console.log("Широта:", position.coords.latitude);
        //             console.log("Долгота:", position.coords.longitude);
        //             console.log("Точность:", position.coords.accuracy, "метров");
        //         },
        //         (error) => {
        //             console.log("Пользователь отказал или ошибка:", error);
        //         }
        //     );
        // }

        isMountedRef.current = true
        if (!isReady) return

        addTime = 1
        const updateduration = async () => {
            if (!isMountedRef.current) return
            if (!addTime && curData.current.durationint < 5) {
                curData.current.durationstr = new Date(curData.current.durationint).toLocaleTimeString('ru-RU')
                await featureLayer.current.applyEdits({
                    updateFeatures: [{ attributes: curData.current }]
                })
            }

            curData.current.durationint += addTime
        }

        const updateData = async () => {
            if (!isMountedRef.current || !featureLayer.current) return
            
            curData.current.durationstr = `${ Math.floor(curData.current.durationint / (3600)) > 0 ? Math.floor(curData.current.durationint / (3600))+':' : '' }${ Math.floor((curData.current.durationint / 60) % 60 ) > 0 ? Math.floor((curData.current.durationint / 60) % 60 )+':' : '' }${ Math.floor(curData.current.durationint % 60 ) }`
            await featureLayer.current.applyEdits({
                updateFeatures: [{ attributes: curData.current }]
            })
        }

        // const resetTimer = () => {
        //     if (!isMountedRef.current) return
        //     addTime = 1
        //     clearTimeout(timeOut.current)
        //     timeOut.current = setTimeout(async () => {
        //         if (!isMountedRef.current || !featureLayer.current) return
        //         addTime = 0
        //         curData.current.durationint = curData.current.durationint
        //         curData.current.lastactint = new Date().toLocaleString('ru-RU')
        //         curData.current.dateoutint = Math.floor(Date.now() / 1000)
        //         await featureLayer.current.applyEdits({
        //             updateFeatures: [{ attributes: curData.current }]
        //         })
        //     }, 5000)
        // }

        const handleVisibilityChange = async () => {
            if (!isMountedRef.current || !featureLayer.current) return
            if (document.hidden) {
                addTime = 0
                // clearTimeout(timeOut.current)
                curData.current.lastactstr = new Date().toLocaleString('ru-RU')
                curData.current.lastactint = Math.floor(Date.now() / 1000)
            } else {
                addTime = 1
                // resetTimer()
                curData.current.dateinstr = new Date().toLocaleString('ru-RU')
                curData.current.dateinint = Math.floor(Date.now() / 1000)
            }
            await featureLayer.current.applyEdits({
                updateFeatures: [{ attributes: curData.current }]
            })
        }

        // const events = ['mousedown', 'mousemove', 'keypress', 'scroll']
        // events.forEach(e => document.addEventListener(e, resetTimer))
        document.addEventListener('visibilitychange', handleVisibilityChange)

        const beforeUnloadHandler = async (event: BeforeUnloadEvent) => {
            if (!featureLayer.current) return
            curData.current.lastactint = new Date().toLocaleString('ru-RU')
            curData.current.dateoutint = Math.floor(Date.now() / 1000)
            await featureLayer.current.applyEdits({
                updateFeatures: [{ attributes: curData.current }]
            })
            event.preventDefault()
            event.returnValue = ''
        }
        window.addEventListener('befoeunload', beforeUnloadHandler)
        window.addEventListener('unload', beforeUnloadHandler)


        handleVisibilityChange()
        timer.current = setInterval(updateduration, 1000)
        updateTimer.current = setInterval(updateData, 10000)

        return () => {
            isMountedRef.current = false
            clearInterval(timer.current)
            clearInterval(updateTimer.current)
            // clearTimeout(timeOut.current)

            // events.forEach(e => document.removeEventListener(e, resetTimer))
            document.removeEventListener('visibilitychange', handleVisibilityChange)
            window.removeEventListener('beforeunload', beforeUnloadHandler)
            window.removeEventListener('unload', beforeUnloadHandler)
        }
    }, [isReady])

    return (
        <DataSourceComponent
            useDataSource={useDataSource}
            onDataSourceCreated={dataSourceCreated}
        />
    )
}