import { React } from "jimu-core";
import { filterStruct } from "../../configs/config";
import { Translations, TranslationKey } from "../../configs/translations";
import "./Indicators.css";

interface IndicatorsProps {
    getFilter: filterStruct;
    getLang: TranslationKey;
}

export default function Indicators({ getFilter, getLang }: IndicatorsProps) {
    const [getIndicatorsData, setIndicatorsData] = React.useState({
        count_area: 0,
        sum_area: 0,
    });
    const [animatedIndicatorsData, setAnimatedIndicatorsData] = React.useState({
        count_area: 0,
        sum_area: 0,
    });

    React.useEffect(() => {
        (async () => {
            const r = await fetch(
                "http://localhost:8080/geoserver/Test/ows?" +
                    "service=WFS&version=2.0.0&request=GetFeature" +
                    "&typeNames=Test:chart_data" +
                    "&outputFormat=application/json" +
                    `&viewparams=field_name:;${Object.entries(getFilter)
                        .map(([key, value]) => key + ":" + value)
                        .join(";")};sort_field:count_area;sort_dir:ASC`,
            );

            const data = await r.json();
            setIndicatorsData(data.features[0].properties);
        })();
    }, [getFilter]);

    React.useEffect(() => {
        const duration = 300;
        const startTime = performance.now();

        const startValues = { ...animatedIndicatorsData };
        const endValues = {
            count_area: Number(getIndicatorsData.count_area) || 0,
            sum_area: Number(getIndicatorsData.sum_area) || 0,
        };

        let frameId: number;

        const updateValues = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            setAnimatedIndicatorsData({
                count_area: Math.round(
                    startValues.count_area +
                        (endValues.count_area - startValues.count_area) *
                            progress,
                ),
                sum_area: Math.round(
                    startValues.sum_area +
                        (endValues.sum_area - startValues.sum_area) * progress,
                ),
            });

            if (progress < 1) {
                frameId = requestAnimationFrame(updateValues);
            }
        };

        frameId = requestAnimationFrame(updateValues);

        return () => cancelAnimationFrame(frameId);
    }, [getIndicatorsData]);

    return (
        <div className="IndicatorsArea">
            <div className="IndicatorsBlock">
                <div className="IndicatorsTitle">
                    {Translations["indicatorTitle"][getLang]}
                </div>

                <div className="IndicatorsInfoBlock">
                    <div className="IndicatorsValue">
                        {animatedIndicatorsData.count_area} ta
                    </div>
                    <div className="IndicatorsName">
                        {Translations["indicatorCount"][getLang]}
                    </div>
                </div>

                <div className="IndicatorsInfoBlock">
                    <div className="IndicatorsValue">
                        {animatedIndicatorsData.sum_area} ga
                    </div>
                    <div className="IndicatorsName">
                        {Translations["indicatorSum"][getLang]}
                    </div>
                </div>
            </div>
        </div>
    );
}
