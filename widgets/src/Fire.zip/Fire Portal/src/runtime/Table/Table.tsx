import { React } from "jimu-core"

import {
    filterStruct,
} from "../../configs/config";
import { Translations, TranslationKey } from "../../configs/translations";
import "./Table.css"

interface TableProps {
	getLang: TranslationKey
}

export default function Table({
	getLang
}: TableProps) {
	const [ isActive, setActive ] = React.useState<boolean>(false)








	return (
		<div className="tableArea">
			<div className="tableDataBlock">
				<div className={`tableRow ${ isActive && "active" }`}>
					<div className="tableCol">GID</div>
					<div className="tableCol">Tuman nomi</div>
					<div className="tableCol">Sana</div>
					<div className="tableCol">Maydon</div>
					<div className="tableCol" onClick={() => setActive(!isActive)}>Status</div>
				</div>
			</div>
			<div className="tablePagination"></div>
		</div>
	)
}
