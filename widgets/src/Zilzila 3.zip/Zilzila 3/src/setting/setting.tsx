/** @jsx jsx */
import { jsx } from 'jimu-core'

export default function Setting() {
    return (
        <div>
            Zilzila 3
        </div>
    )
}