import { React } from "jimu-core"
import "./Widget.css"

import CustomMap from "./CustomMap/CustomMap"

export default function Widget() {
    const years = [
        "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025"
    ]
    const currYear = React.useRef(0)

    return (
        <div className="mainArea">
            <CustomMap/>
        </div>
    )
}