import { React } from "jimu-core"

import Map from "@arcgis/core/Map"
import MapView from "@arcgis/core/views/MapView"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import HeatmapRenderer from "@arcgis/core/renderers/HeatmapRenderer";
import * as heatmapRendererCreator from "@arcgis/core/smartMapping/renderers/heatmap";
import SimpleRenderer from "@arcgis/core/renderers/SimpleRenderer";
import SimpleMarkerSymbol from "@arcgis/core/symbols/SimpleMarkerSymbol";
import ColorVariable from "@arcgis/core/renderers/visualVariables/ColorVariable";
import SizeVariable from "@arcgis/core/renderers/visualVariables/SizeVariable";

interface customMapProps {

}

export default function CustomMap(props: customMapProps) {
    const center = [64.9865, 41.0835]
    const mapContainerRef = React.useRef<HTMLDivElement>(null)
    const [view, setView] = React.useState<MapView | null>(null)
    const [mainBaseMap, setBaseMap] = React.useState("hybrid")
    const epiPoint = React.useRef<FeatureLayer | null>(null)

    function updateVisibility(value: string) {
        epiPoint.current.definitionExpression = `date LIKE '%${value}'`

        epiPoint.current.featureEffect = {
            filter: {
                where: `date LIKE '%${value}'`
            },
            excludedEffect: "opacity(10%)"
        };
    }

    React.useEffect(() => {
        if (!mapContainerRef.current) return

        epiPoint.current = new FeatureLayer({
            url: "https://gis.uzspace.uz/uzspacesrvr/rest/services/Hosted/ZilzilaPoints/FeatureServer",
            renderer: new HeatmapRenderer({
                field: "magnitude",
                radius: 20,
                minDensity: 0.000001,
                maxDensity: 0.025,
                colorStops: [
                    { ratio: 0, color: "rgba(255,255,255,0)" },
                    { ratio: 0.3, color: "#ffe5e5" },
                    { ratio: 0.6, color: "#ff9999" },
                    { ratio: 1, color: "#cc0000" }
                ]
            })
        });

        const map = new Map({
            basemap: mainBaseMap,
        })

        const mapView = new MapView({
            container: mapContainerRef.current,
            map,
            zoom: 6,
            center: center,
            ui: {
                components: [],
            }
        })

        map.add(epiPoint.current)
        setView(mapView)

        mapView.container.tabIndex = 0
        mapView.focus()

        mapView.on("key-down", (event) => {
            event.stopPropagation()
            if (event.key === "v") {
                if (epiPoint.current) {
                    epiPoint.current.visible = !epiPoint.current.visible
                }
            }
            if (event.key === "ArrowRight") {
                currYear.current = (currYear.current + 1) % years.length
                updateVisibility(years[currYear.current])
            }
            if (event.key === "ArrowLeft") {
                currYear.current = (currYear.current - 1) < 0 ? years.length - 1 : currYear.current - 1
                updateVisibility(years[currYear.current])
            }
        })

        mapView.on("click", () => {
            mapView.focus()
        })

        return () => {
            mapView.destroy()
        }
    }, [])

    return (
        <div
            ref={mapContainerRef}
            className="mapArea"
        />
    )
}