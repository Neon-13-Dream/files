import { React } from "jimu-core"
import type MapView from "esri/views/MapView"
import "./Home.css"

import home from "../../assets/imgs/home.png"

interface homeProps {
	map: MapView,
	point: {
		x: number,
		y: number
	}
	zoom?: number
}

export default function Home(props: homeProps) {
	return (
		<div className="homeBtn" onClick={() => {
			props.map.goTo({
				center: [props.point.x, props.point.y],
				zoom: props.zoom
			}, {
				duration: 2000,
				easing: "in-out-cubic",
			})
		}}>
			<img src={home} />
		</div>
	)
}
