import { React } from "jimu-core"
import {
	defaultFilter,
	type dataFilterStruct
} from "./config"
import Map from "esri/Map"
import MapView from "esri/views/MapView"
import Graphic from "@arcgis/core/Graphic"
import Point from "@arcgis/core/geometry/Point"
import Circle from "@arcgis/core/geometry/Circle"
import SimpleMarkerSymbol from "@arcgis/core/symbols/SimpleMarkerSymbol"
import SimpleFillSymbol from "@arcgis/core/symbols/SimpleFillSymbol"
import GraphicsLayer from "@arcgis/core/layers/GraphicsLayer"
import FeatureLayer from "@arcgis/core/layers/FeatureLayer"
import UniqueValueRenderer from "@arcgis/core/renderers/UniqueValueRenderer"

import MyTable from "./assets/Table/Table"
import PageMove from "./assets/PageMove/PageMove"
import Selector from "./assets/Selector/Selector"
import Filter from "./assets/Filter/Filter"
import Home from "./Bottons/Home/Home"
import MinMaxBar from "./Bottons/MiMaxBar/MinMaxBat"
import "./style.css"

import showImg from "./assets/imgs/visible.png"
import hiddenImg from "./assets/imgs/hide.png"
import filterClose from "./assets/imgs/filter.png"
import filterOpen from "./assets/imgs/filter open.png"


export default function CustomMapWidget() {
	const center = [64.9865, 41.0835]
	const mapContainerRef = React.useRef<HTMLDivElement>(null)
	const [view, setView] = React.useState<MapView | null>(null)
	const [mainBaseMap, setBaseMap] = React.useState("hybrid")

	const url = "https://api-zilzila.spacemc.uz/api/earthquakes/"
	const [filter, setFilter] = React.useState<dataFilterStruct>(defaultFilter)

	const [getData, setData] = React.useState([])
	const maxPage = React.useRef(1)
	const dataCount = React.useRef(1)
	const [sortType, setSortType] = React.useState("Eng yangi")
	const [isTableVisible, setTableVisible] = React.useState(true)
	const [isFilterVisible, setFilterVisible] = React.useState(false)

	const allPoints = React.useRef<Array<{ point: Graphic; circle: Graphic }>>([])
	const [activePointId, setActivePointId] = React.useState<number>(-1)

	function getRadius(magnitude: number, depth: number): number {
		return ((10 ** (0.5 * magnitude - 1) * 100) / Math.sqrt(depth + 1)) * 1000
	}

	function energy(magnitude: number) {
		return Math.round(10 ** (magnitude * 1.8 - 6) * 1000) / 1000
	}

	function useDebouncedEffect(effect: () => void, deps: any[], delay: number) {
		React.useEffect(() => {
			const handler = setTimeout(() => {
				effect()
			}, delay)

			return () => { clearTimeout(handler) }
		}, [...deps, delay])
	}

	useDebouncedEffect(() => {
		fetch(`${url}?${Object.entries(filter).map(([key, value]: any) => { return value === "" ? "" : key + "=" + value }).join("&")}`)
			.then((result: any) => result.json())
			.then((data: any) => {
				maxPage.current = data.last_page
				dataCount.current = data.total

				if (data.total < 10) {
					allPoints.current.forEach((item: any) => {
						item.point.visible = false
					})
				}

				data.data.forEach((item: any, index: number) => {
					const newPointGeom = new Point({
						longitude: item.longitude,
						latitude: item.latitude,
						spatialReference: { wkid: 4326 }
					})

					const newCircleGeom = new Circle({
						center: newPointGeom,
						radius: getRadius(item.magnitude, item.depth)
					})
					allPoints.current[index].point.geometry = newPointGeom
					allPoints.current[index].point.symbol.color = item.color

					allPoints.current[index].circle.geometry = newCircleGeom
					allPoints.current[index].circle.symbol.color = item.color + "34"
					allPoints.current[index].circle.symbol.outline.color = item.color + "88"
					allPoints.current[index].circle.symbol.outline.width = 1

					allPoints.current[index].point.visible = true
				})


				setData(data.data.map((obj: any) => ({
					...obj,
					energy: energy(obj.magnitude)
				})))
			})
	}, [filter], 300)

	React.useEffect(() => {
		console.log(view)

		if (!view) return


		allPoints.current.forEach((g: any) => {
			g.circle.visible = false
		})
		if (activePointId >= 0) {
			view.goTo(allPoints.current[activePointId].point, {
				duration: 500,
				easing: "in-out-cubic"
			})

			allPoints.current[activePointId].circle.visible = true
		}

	}, [activePointId, view])

	React.useEffect(() => {
		if (!mapContainerRef.current) return

		const map = new Map({
			basemap: mainBaseMap,
		})

		const mapView = new MapView({
			container: mapContainerRef.current,
			map,
			zoom: 6,
			center: center,
			ui: {
				components: [],
			}
		})

		const pointsLayer = new GraphicsLayer({ id: "pointsLayer" })
		const circlesLayer = new GraphicsLayer({ id: "circlesLayer" })

		for (let pIndex = 0; pIndex < defaultFilter.per_page; pIndex++) {
			const pointGeom = new Point({
				longitude: center[0],
				latitude: center[1],
				spatialReference: { wkid: 4326 }
			})

			const circleGeom = new Circle({
				center: pointGeom,
				radius: getRadius(3, 5)
			})

			const pointGraphic = new Graphic({
				geometry: pointGeom,
				symbol: new SimpleMarkerSymbol({
					color: "#00000000",
					size: 12,
					outline: { color: "#00000000", width: 1 }
				})
			})

			const circleGraphic = new Graphic({
				geometry: circleGeom,
				symbol: new SimpleFillSymbol({
					color: "#00000000",
					outline: { color: "#00000000", width: 1 }
				}),
				visible: false
			})

			allPoints.current.push({
				point: pointGraphic,
				circle: circleGraphic
			})
			pointsLayer.add(pointGraphic)
			circlesLayer.add(circleGraphic)
		}

		map.addMany([circlesLayer, pointsLayer])
		setView(mapView)

		mapView.watch("zoom", (newValue: any) => {
			console.log(newValue)
		})

		return () => {
			mapView.destroy()
		}
	}, [])

	return (
		<div className="mainArea">
			<Filter
				filter={filter}
				onChange={(e: any) => { setFilter(e) }}
				active={isFilterVisible}
				close={(e: any) => { setFilterVisible(e) }}
			/>

			<Home
				map={view}
				point={{ x: 64.9865, y: 41.0835 }}
				zoom={6}
			/>

			<div
				ref={mapContainerRef}
				className="mapArea"
			>
				<div className={`bottomArea ${isTableVisible ? "activ" : ""}`}>
					<MinMaxBar
						minValue={0}
						maxValue={10}
						onChange={(min: any, max: any) => {
							setFilter({
								...filter,
								from_magnitude: min,
								to_magnitude: max,
							})
						}}
						step={0.1}
						minGap={0.5}
						inclusive={true}
						initialMin={filter.from_magnitude}
						initialMax={filter.to_magnitude}
					/>
					<div className="tableInfoArea">
						<div className="tableBottom">
							<div className="dataInfoArea">
								<div className="dataInfoTitle">Zilzilalar ro'yxati</div>
								<div className="dataInfo" style={{ display: 'none' }} >
									<strong>
										Jami:&nbsp;
									</strong>
									{dataCount.current}&nbsp;&nbsp;
									<strong>
										Sahifa:&nbsp;
									</strong>
									{filter.page + 1}
									( 1 - {maxPage.current} )
								</div>
							</div>
							<PageMove
								value={filter.page + 1}
								minPage={1}
								maxPage={maxPage.current}
								onChange={(index: number) => {
									setFilter({
										...filter,
										page: index - 1
									})
								}}
								pageRadius={2}
							/>
							<div className="buttons">
								<Selector
									value={sortType}
									options={["Eng yangi", "Eng eski"]}
									onChange={(selected: string) => {
										setSortType(selected)
										switch (selected) {
											case "Eng yangi":
												setFilter({
													...filter,
													sort: "datetime_desc"
												})
												break
											case "Eng eski":
												setFilter({
													...filter,
													sort: "datetime_asc"
												})
												break
											default:
												setFilter({
													...filter,
													sort: "datetime_desc"
												})
												break
										}
									}}
									openUp={isTableVisible}
								/>

								<div className="headerBtn" onClick={() => { setFilterVisible(!isFilterVisible) }}>
									<img src={isFilterVisible ? filterOpen : filterClose} />
								</div>

								<div className="headerBtn" onClick={() => { setTableVisible(!isTableVisible) }}>
									<img src={isTableVisible ? hiddenImg : showImg} />
								</div>
							</div>
						</div>

						<MyTable
							data={getData}
							onChange={(index: number) => { setActivePointId(index) }}
							page={filter.page}
							per_page={filter.per_page}
						/>
					</div>
				</div>
			</div>
		</div>
	)
}
