// Types
type numFilter = "" | number
export const sortFilterValues = [
	"datetime_desc",
	"datetime_asc"
] as const
export type sortFilter = typeof sortFilterValues[number];
type userSelect = "none" | "auto" | "text" | "all" | "contain" | "element";

interface fieldsConf {
	name: string
	width: string
	activ: boolean
	uSelect: userSelect
}

export interface tableConf {
	date: fieldsConf,
	time: fieldsConf,
	latitude: fieldsConf,
	longitude: fieldsConf,
	depth: fieldsConf,
	magnitude: fieldsConf,
	epicenter: fieldsConf,
	energy: fieldsConf
}

export interface dataFilterStruct {
	sort: sortFilter,
	per_page: number,
	page: number,
	epicenter: string,
	from_date: string,
	to_date: string,
	from_magnitude: numFilter,
	to_magnitude: numFilter,
	from_depth: numFilter,
	to_depth: numFilter,
	from_latitude: numFilter,
	to_latitude: numFilter,
	from_longitude: numFilter,
	to_longitude: numFilter
}

// Configs
export const baseMaps = {
	"vector": [
		"streets-vector",
		"streets-night-vector",
		"streets-navigation-vector",
		// "topographic-vector",
		"topo-vector",
		"streets-relief-vector",
		// "streets-day-vector",
		// "streets-open-street-map",
		"dark-gray-vector",
		"dark-gray",
		// "light-gray-vector",
		// "light-gray",
		// "human-geography",
		// "human-geography-dark",
		// "human-geography-light",
		// "osm-light-gray",
		// "osm-standard",
		// "osm-standard-relief",
		// "osmpictorial"
	],
	"raster": [
		"satellite",
		"hybrid",
		"terrain",
		"topo",
		"oceans"
	]
}

export const defaultFilter: dataFilterStruct = {
	sort: "datetime_desc",
	per_page: 10,
	page: 0,

	epicenter: "",

	from_date: "",
	to_date: "",

	from_latitude: "",
	to_latitude: "",

	from_longitude: "",
	to_longitude: "",

	from_depth: "",
	to_depth: "",

	from_magnitude: "",
	to_magnitude: ""
}

export const idConf: fieldsConf = {
	name: "№",
	width: "3%",
	activ: false,
	uSelect: "none"
}

export const defaultTableConf: tableConf = {
	date: {
		name: "Sana",
		width: "14%",
		activ: false,
		uSelect: "none"
	},
	time: {
		name: "Vaqt",
		width: "14%",
		activ: false,
		uSelect: "none"
	},
	latitude: {
		name: "Kenglik",
		width: "10%",
		activ: false,
		uSelect: "none"
	},
	longitude: {
		name: "Uzoqlik",
		width: "10%",
		activ: false,
		uSelect: "none"
	},
	depth: {
		name: "Chuqurlik",
		width: "10%",
		activ: false,
		uSelect: "none"
	},
	magnitude: {
		name: "Magnituda",
		width: "10%",
		activ: false,
		uSelect: "none"
	},
	energy: {
		name: "Energiya",
		width: "10%",
		activ: false,
		uSelect: "none"
	},
	epicenter: {
		name: "Zilzila epitsentri",
		width: "21%",
		activ: false,
		uSelect: "text"
	}
}
