import { React } from "jimu-core"
import {
	type tableConf,
	defaultTableConf, idConf
} from "../../config"
import "./Table.css"

export interface tableProps {
	data: any
	page: number
	per_page: number
	onChange: (index: number) => void
}

export default function MyTable(props: tableProps) {
	const [activeItemId, setActiveItemId] = React.useState<number>(-1)
	const withIndex = true

	const valueFilter = (fieldName: string, value: any) => {
		switch (fieldName) {
			case "magnitude":
				return Math.floor(value * 10) / 10
			case "longitude":
			case "latitude":
				return Math.floor(value * 100) / 100
			case "time":
				return value.split('.')[0]
			default:
				return value
		}
	}

	return (
		<div className="tableArea">
			<div className="tableFieldsArea">
				{withIndex && (
					<div className="tableField" style={{ width: idConf.width }}>{idConf.name}</div>
				)}

				{(Object.keys(defaultTableConf) as Array<keyof tableConf>).map((fields) => (
					<div className="tableField" style={{ width: defaultTableConf[fields].width }}>{defaultTableConf[fields].name}</div>
				))}
			</div>

			<div className="tableValuesArea">
				{props.data.map((row: any, index: number) => (
					<div className={`tableRow ${index === activeItemId ? "activ" : ""}`} onClick={() => {
						setActiveItemId(index === activeItemId ? -1 : index)
						props.onChange(index === activeItemId ? -1 : index)
					}}>
						{withIndex && (<div className="tableValue" style={{ width: idConf.width }}>{1 + index + props.page * props.per_page}</div>)}

						{(Object.keys(defaultTableConf) as Array<keyof tableConf>).map((fields) => (
							<div
								className="tableValue"
								style={{
									width: defaultTableConf[fields].width,
									userSelect: defaultTableConf[fields].uSelect
								}}
								title={fields === "epicenter" ? row.description : ""}
							>
								{valueFilter(fields, row[fields])}
								{/*fields === "magnitude" && (
									<span className="block"
										style={{
											backgroundColor: `${row.color}`,
										}}
									></span>
								)*/}
							</div>
						))}


					</div>
				))}
				<div className="scrollArea">

				</div>
			</div>
		</div>
	)
}
