import { React } from "jimu-core"
import "./PageMove.css"

interface pageProps {
	value: number
	minPage: number
	maxPage: number
	onChange: (pageIndex: number) => void
	pageRadius: number
}

export default function PageMove(props: pageProps) {
	const [getCurrValue, setCurrValue] = React.useState<number | "">(props.value)

	function rangeArray(n: number): number[] {
		const result: number[] = []
		for (let i = -n; i <= n; i++) {
			result.push(i)
		}
		return result
	}

	function update(pageIndex: number) {
		const clampedValue = Math.max(props.minPage, Math.min(props.maxPage, pageIndex))
		setCurrValue(clampedValue)
		props.onChange(clampedValue)
	}

	return (
		<div className="pageArea">
			<div className={`pageBtn ${props.value <= props.minPage ? "diactiv" : "activ"}`} onClick={() => { update(props.value - 1) }}>{"<"}</div>
			{
				rangeArray(props.pageRadius).map((item, index) => {
					const pageNumber = props.value + item
					if (props.minPage <= pageNumber && pageNumber <= props.maxPage) {
						return item === 0 ? (
							<input
								type="number"
								className="pageInput"
								value={getCurrValue}
								onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
									const val = e.target.value
									if (val === "") {
										setCurrValue("")
										return
									}
									const num = parseInt(val)
									if (!isNaN(num)) setCurrValue(num)
								}}
								onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
									if (e.key === "Enter") {
										if (getCurrValue === "") {
											update(props.minPage)
										} else {
											update(Number(getCurrValue))
										}
									}
								}}
								key={index}
							/>
						) : (
							<div className="pageBtn" onClick={() => { update(pageNumber) }} key={index}>
								{pageNumber}
							</div>
						)
					} else {
						return <div className="pageBtn diactiv" key={index}>-</div>
					}
				})
			}
			<div className={`pageBtn ${props.value >= props.maxPage ? "diactiv" : "activ"}`} onClick={() => { update(props.value + 1) }}>{">"}</div>
		</div>
	)
}
