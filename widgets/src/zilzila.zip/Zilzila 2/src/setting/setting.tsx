/** @jsx jsx */
import { React, jsx } from 'jimu-core'
import type { AllWidgetSettingProps } from 'jimu-for-builder'

export default function Setting(props: AllWidgetSettingProps<any>) {
    return (
        <div>
            Zilzila
        </div>
    )
}