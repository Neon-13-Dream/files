import { React } from "jimu-core"
import "./Filter.css"

import Calendar from "../Calendar/Calendar"
import MinMaxBar from "../MinMaxBar/MinMaxBat"

interface filterData {
	date_from: string
	date_to: string
	bulut_from: string
	bulut_to: string
}

export default function Filter() {
	const [getFilter, setFilter] = React.useState<filterData>({
		date_from: "",
		date_to: "",
		bulut_from: "",
		bulut_to: ""
	})

	const updateFilter = (field: string, value: any) => {
		setFilter((prev: any) => {
			return {
				...prev,
				[field]: value
			}
		})
	}



	return (
		<div className="FilterArea">
			<div className="FilterBlock">
				<div className="FilterTitle">Sanalar oralig’i:</div>
				<Calendar
					value={getFilter.date_from}
					minDate={"01/01/2000"}
					onChange={(val: string) => {
						updateFilter("date_from", val)
					}}
					weekDays={["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]}
					monthNames={["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"]}
					className="FilterDate"
					placeholder="KK/OO/YYYY"
					format="%D/%M/%Y"
				/>
				<Calendar
					value={getFilter.date_to}
					minDate={getFilter.date_from}
					onChange={(val: string) => {
						updateFilter("date_from", val)
					}}
					weekDays={["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]}
					monthNames={["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"]}
					className="FilterDate"
					placeholder="KK/OO/YYYY"
					format="%D/%M/%Y"
				/>
			</div>
			<div className="FilterBlock">
				<div className="FilterTitle">Bulut qoplami (%):</div>

				<MinMaxBar
					minValue={0}
					maxValue={10}
					onChange={(min: any, max: any) => {
						updateFilter("bulut_from", min)
						updateFilter("bulut_to", max)
					}}
					step={0.1}
					minGap={0.5}
					inclusive={true}
					initialMin={getFilter.bulut_from}
					initialMax={getFilter.bulut_to}
				/>
			</div>
		</div>
	)
}
