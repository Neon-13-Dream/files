import { React } from "jimu-core"
import "./MinMaxBar.css"

interface barValues {
	minVal: number;
	maxVal: number;
}

interface minMaxBarProps {
	minValue: number;
	maxValue: number;
	step: number;
	minGap?: number;
	inclusive?: boolean;
	onChange: (min: number, max: number) => void;
	initialMin?: number | "";
	initialMax?: number | "";
}

export default function MinMaxBar(props: minMaxBarProps) {
	const barRef = React.useRef<HTMLDivElement>(null)
	const minRef = React.useRef<HTMLDivElement>(null)
	const maxRef = React.useRef<HTMLDivElement>(null)

	const [controlType, setType] = React.useState<"none" | "min" | "max">("none")
	const [mode, setMode] = React.useState<"interval" | "single">("interval")

	const range = props.maxValue - props.minValue

	const clampAndStep = (val: number) => {
		const v = Math.max(props.minValue, Math.min(val, props.maxValue))
		const steps = Math.round((v - props.minValue) / props.step)
		return Number((props.minValue + steps * props.step).toFixed(6))
	}

	const [currValues, setValues] = React.useState<barValues>({
		minVal: props.initialMin === "" || props.initialMin === undefined ? props.minValue : clampAndStep(props.initialMin),
		maxVal: props.initialMax === "" || props.initialMax === undefined ? props.maxValue : clampAndStep(props.initialMax),
	})

	// Синхронизация с initialMin/Max
	React.useEffect(() => {
		const newMin = props.initialMin === "" || props.initialMin === undefined ? props.minValue : clampAndStep(props.initialMin)
		const newMax = props.initialMax === "" || props.initialMax === undefined ? props.maxValue : clampAndStep(props.initialMax)
		setValues({ minVal: newMin, maxVal: newMax })
	}, [props.initialMin, props.initialMax, props.minValue, props.maxValue])

	// Обновление позиции ползунков
	React.useEffect(() => {
		const bar = barRef.current
		if (!bar) return
		const width = bar.getBoundingClientRect().width

		const minPercent = (currValues.minVal - props.minValue) / range
		const maxPercent = (currValues.maxVal - props.minValue) / range

		if (minRef.current) minRef.current.style.left = `${minPercent * width}px`
		if (maxRef.current && mode === "interval") maxRef.current.style.left = `${maxPercent * width}px`
	}, [currValues, range, mode])

	// Обработчик движения мыши
	React.useEffect(() => {
		const bar = barRef.current
		if (!bar) return

		const barRect = bar.getBoundingClientRect()
		const barWidth = barRect.width
		const minGap = props.minGap ?? 0

		const move = (e: MouseEvent) => {
			if (controlType === "none") return

			let mouseX = e.clientX - barRect.left
			mouseX = Math.max(0, Math.min(mouseX, barWidth))
			const percent = mouseX / barWidth

			const rawValue = props.minValue + percent * range
			const steps = Math.round((rawValue - props.minValue) / props.step)
			let realValue = Number((props.minValue + steps * props.step).toFixed(6))
			realValue = Math.max(props.minValue, Math.min(realValue, props.maxValue))

			// SINGLE MODE
			if (mode === "single") {
				if (minRef.current) {
					const newPercent = (realValue - props.minValue) / range
					minRef.current.style.left = `${newPercent * barWidth}px`
				}
				setValues({ minVal: realValue, maxVal: realValue })

				let ret = realValue
				if (!props.inclusive) ret = Number((realValue + props.step).toFixed(6))
				props.onChange(ret, ret)
				return
			}

			// INTERVAL MODE
			if (controlType === "min") {
				realValue = Math.min(realValue, currValues.maxVal - minGap)
				if (minRef.current) {
					const newPercent = (realValue - props.minValue) / range
					minRef.current.style.left = `${newPercent * barWidth}px`
				}
				setValues((v) => {
					const updated = { ...v, minVal: realValue }
					let retMin = updated.minVal
					let retMax = updated.maxVal
					if (!props.inclusive) {
						retMin = Number((retMin + props.step).toFixed(6))
						retMax = Number((retMax - props.step).toFixed(6))
					}
					props.onChange(retMin, retMax)
					return updated
				})
			}

			if (controlType === "max") {
				realValue = Math.max(realValue, currValues.minVal + minGap)
				if (maxRef.current) {
					const newPercent = (realValue - props.minValue) / range
					maxRef.current.style.left = `${newPercent * barWidth}px`
				}
				setValues((v) => {
					const updated = { ...v, maxVal: realValue }
					let retMin = updated.minVal
					let retMax = updated.maxVal
					if (!props.inclusive) {
						retMin = Number((retMin + props.step).toFixed(6))
						retMax = Number((retMax - props.step).toFixed(6))
					}
					props.onChange(retMin, retMax)
					return updated
				})
			}
		}

		const stop = () => { setType("none") }

		document.addEventListener("mousemove", move)
		document.addEventListener("mouseup", stop)

		return () => {
			document.removeEventListener("mousemove", move)
			document.removeEventListener("mouseup", stop)
		}
	}, [controlType, currValues, mode, range, props])

	return (
		<div className="MinMaxBarArea">
			<div className="barTitle">
				Magnituda
				<div
					className="modeSwitch"
					onClick={() => {
						if (mode === "interval") {
							setMode("single")
							props.onChange(currValues.minVal, currValues.minVal)
						} else {
							setMode("interval")
							props.onChange(currValues.minVal, currValues.maxVal)
						}
					}}
				>
					{mode === "interval" ? "Single" : "Interval"}
				</div>
			</div>

			<div className="barArea">
				<div className="values">{props.minValue}</div>

				<div className="bar" ref={barRef}>
					<div className="valueControl min" ref={minRef}>
						<div
							className={`control ${controlType === 'min' ? 'activ' : ''}`}
							onMouseDown={() => { setType("min") }}
						></div>
						<div className="barValues">{currValues.minVal}</div>
					</div>

					{mode === "interval" && (
						<div className="valueControl max" ref={maxRef}>
							<div
								className={`control ${controlType === 'max' ? 'activ' : ''}`}
								onMouseDown={() => { setType("max") }}
							></div>
							<div className="barValues">{currValues.maxVal}</div>
						</div>
					)}
				</div>

				<div className="values">{props.maxValue}</div>
			</div>
		</div>
	)
}
