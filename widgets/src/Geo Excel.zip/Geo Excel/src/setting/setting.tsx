/** @jsx jsx */
import {
	React, jsx, Immutable,
	DataSourceTypes
} from 'jimu-core'

import type { AllWidgetSettingProps } from 'jimu-for-builder'
import { DataSourceSelector } from 'jimu-ui/advanced/data-source-selector'
import { ColorPicker } from 'jimu-ui/basic/color-picker'
import { type IMConfig, defaultConfig } from '../config'


export default function Setting(props: AllWidgetSettingProps<IMConfig>) {
	const config = props.config || defaultConfig
	const saveHandler = (useDataSources: any[]) => {
		props.onSettingChange({
			id: props.id,
			useDataSources: useDataSources
		})
	}

	const onColorChange = (color: any) => {
		props.onSettingChange({
			id: props.id,
			config: config.set('selectedColor', color)
		})
	}

	return (
		<div style={{
			padding: "15px"
		}}>
			<h4 style={{
				textAlign: "center",
				color: "#fff"
			}}>
				Select Geologiya feature layer
			</h4>
			<DataSourceSelector
				mustUseDataSource
				types={Immutable([DataSourceTypes.FeatureLayer])}
				useDataSources={props.useDataSources}
				onChange={saveHandler}
				widgetId={props.id}
			/>

			<div style={{
				display: 'flex',
				alignItems: 'center',
				justifyContent: 'flex-start',
				margin: '10px',
				gap: '10px'
			}}>
				<h6 style={{
					color: "#fff",
					margin: 0,
					fontWeight: 500
				}}>
					Цвет выбранного
				</h6>

				<ColorPicker
					color={config.selectedColor || 'rgba( 142, 253, 142, 255 )'}
					onChange={onColorChange}
					width={30}
					placement="left"
				/>
			</div>
		</div>
	)
}
