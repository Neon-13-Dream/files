import { React, Immutable, type ImmutableObject } from 'jimu-core'

export interface Config {
	selectedColor: string
}

export type IMConfig = ImmutableObject<Config>

export const defaultConfig: IMConfig = Immutable({
	selectedColor: 'rgba( 142, 253, 142, 255 )'
})

// Основные переменные
export const uName = [ // Названия облостей и городов + Жами
	"Жами",
	"Андижон вилояти",
	"Бухоро вилояти",
	"Жиззах вилояти",
	"Навоий вилояти",
	"Наманган вилояти",
	"Самарқанд вилояти",
	"Сирдарё вилояти",
	"Сурхондарё вилояти",
	"Тошкент вилояти",
	"Тошкент шаҳар",
	"Фарғона вилояти",
	"Хоразм вилояти",
	"Қашқадарё вилояти",
	"Қорақалпогистон Республикаси"
]

export const uType = [ // Название нужных нам типов
	"Космик мониторинг орқали аниқланган жами қонун бузилишларининг сони",
	"Инспекция томонидан ўрганилган қонун бузилиш ҳолатларининг умумий сони",
	"Қонун бузулиш ҳолати ўз тасдиғини топди",
	"Қонун бузулиш ҳолати ўз тасдиғини топмади",
	"Номаълум шахслар томонидан қазиб олинган",
	"Инспекция томонидан ҳали  ўрганиш ишлари олиб борилмаган"
]
export const otherValue = [2, 3, 4] // Индексы интересующих нас типов ( в данном случае мы должны вычислять их сумму )

export const allGroups = {
	"ALL": {
		"Kiril": "ALL",
		"group": ["Rahbariyat", "SGM", "Geology", "Schetnaya palata", "Another"]
	},
	'Toshkent viloyati': {
		"Kiril": 'Тошкент вилояти',
		"group": ['Toshkent viloyati']
	},
	'Xorazm': {
		"Kiril": "Хоразм",
		"group": ['Xorazm']
	},
	'Sirdaryo': {
		"Kiril": "Сирдарё",
		"group": ['Sirdaryo']
	},
	"Qoraqalpogiston": {
		"Kiril": "Қорақалпогистон",
		"group": ["Qoraqalpogiston"]
	},
	'Buxoro': {
		"Kiril": "Бухоро",
		"group": ['Buxoro']
	},
	'Namangan': {
		"Kiril": "Наманган",
		"group": ['Namangan']
	},
	'Surxondaryo': {
		"Kiril": "Сурхондарё",
		"group": ['Surxondaryo']
	},
	'Qashqadaryo': {
		"Kiril": "Қашқадарё",
		"group": ['Qashqadaryo']
	},
	'Andijon': {
		"Kiril": "Андижон",
		"group": ['Andijon']
	},
	'Jizzax': {
		"Kiril": "Жиззах",
		"group": ['Jizzax']
	},
	'Navoiy': {
		"Kiril": "Навоий",
		"group": ['Navoiy']
	},
	"Farg`ona": {
		"Kiril": "Фарғона",
		"group": ["Farg'ona"]
	},
	'Samarqand': {
		"Kiril": "Самарқанд",
		"group": ['Samarqand']
	},
	'Toshkent shahar': {
		"Kiril": "Тошкент шаҳар",
		"group": ['Toshkent shahar']
	}
}

// export const downloadFile = (blob: Blob, filename: string) => {
// 	const url = URL.createObjectURL(blob)
// 	window.top.open(url, '_blank')
// 	console.log("Downloaded: ", filename)
// }

export const downloadFile = (blob: Blob, filename: string) => {
	const url = URL.createObjectURL(blob);

	const newTab = window.open('', '_blank');
	if (newTab) {
		newTab.document.write(`
          <html>
            <head>
              <title>Downloading ${filename}</title>
            </head>
            <body>
              <script>
                const link = document.createElement('a');
                link.href = '${url}';
                link.download = '${filename.replace(/'/g, "\\'")}';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                setTimeout(() => window.close(), 200);
              </script>
              <p>Downloading ${filename}...</p>
            </body>
          </html>
        `);
	}

	console.log("Downloaded: ", filename);

	setTimeout(() => {
		URL.revokeObjectURL(url);
	}, 5000);
}