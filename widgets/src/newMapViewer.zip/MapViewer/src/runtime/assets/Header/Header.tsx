import { React } from "jimu-core"
import "./Header.css"

import HeaderImg from "../imgs/Uzcosmos Logo/uzcosmos logo white.png"
import SearchIcon from "../imgs/Search.png"
import PolygonIcon from "../imgs/Polygon.png"
import ReactangleIcon from "../imgs/Rectangle.png"
import CircleIcon from "../imgs/Circle.png"
import ImportIcon from "../imgs/Import.png"
import LocationIcon from "../imgs/Location.png"

interface headerProps {
    onChange: (type: string, data: any) => void
}

export default function Header(props: headerProps) {
    const [getType, setType] = React.useState("none")
    const [getInputValue, setInputValue] = React.useState<string>("")
    const [getResult, setResult] = React.useState<any[]>([])
    const debounceRef = React.useRef<NodeJS.Timeout | null>(null)
    const [isInputFocused, setFocus] = React.useState(false)

    const updateType = (type: string, data: any) => {
        if (type === "address") {
            setType("address")
            setInputValue(data)
            props.onChange("address", data)
            return
        }

        if (type !== getType) {
            setType(type)
            props.onChange(type, data)
        }
        else {
            setType("none")
            props.onChange("none", "")
        }
    }

    const PlaceSearch = async (input: string) => {
        const query = `Uzbekiston ${input}`;
        const url = `https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?f=json&SingleLine=${encodeURIComponent(query)}&outSR=4326&maxLocations=10`;
        const response = await fetch(url);
        const data = await response.json();
        setResult(data.candidates);
    }

    const handleInput = (text: string) => {
        setInputValue(text);

        if (debounceRef.current) clearTimeout(debounceRef.current);

        debounceRef.current = setTimeout(() => {
            if (text.trim().length === 0) {
                setResult([]);
                return;
            }

            PlaceSearch(text);
        }, 300);
    };

    return (
        <div className="HeaderArea">
            <div className="HeaderLeftContent">
                <div className="HeaderLogo">
                    <img src={HeaderImg} />
                </div>
                <div className="HeaderActions">
                    <div className="HeaderInputArea">
                        <div className="HeaderInputSearch"><img src={SearchIcon} /></div>
                        <input
                            type="text"
                            className="HeaderInput"
                            value={getInputValue}
                            onChange={(event: any) => { handleInput(event.target.value) }}
                            onFocus={() => setFocus(true)}
                            onBlur={() => { setTimeout(() => setFocus(false), 100) }}
                            onKeyDown={(event: any) => {
                                if (event.code === "Enter") {
                                    updateType("address", getResult[0].extent)
                                }
                            }}
                            placeholder="Manzilni qidirish"
                        />
                        {getInputValue.length > 0 && isInputFocused && <div className="HeaderInputResultArea">
                            {getResult.map((item: any) => (
                                <div className="ResultItem" onClick={() => {
                                    updateType("address", item.extent)
                                }}>
                                    <div className="ResultIcon"><img src={LocationIcon} /></div>
                                    <div className="ResultItmTitle">{item.address}</div>
                                </div>
                            ))}
                        </div>}
                    </div>
                    <div className={`HeaderBtn ${ getType === "Polygon" ? 'activ' : '' }`} onClick={() => updateType("Polygon", "Polygon")}><img src={PolygonIcon} /></div>
                    <div className={`HeaderBtn ${ getType === "Circle" ? 'activ' : '' }`} onClick={() => updateType("Circle", "Circle")}><img src={CircleIcon} /></div>
                    <div className={`HeaderBtn ${ getType === "Reactangle" ? 'activ' : '' }`} onClick={() => updateType("Reactangle", "Reactangle")}><img src={ReactangleIcon} /></div>
                    <div className={`HeaderBtn`} onClick={() => props.onChange("Import", "Import")}><img src={ImportIcon} /></div>
                </div>
            </div>
            <div className="HeaderRightContent">
                <div className="HeaderBtn"></div>
                <div className="HeaderBtn"></div>
                <div className="HeaderBtn"></div>
            </div>
        </div>
    )
}