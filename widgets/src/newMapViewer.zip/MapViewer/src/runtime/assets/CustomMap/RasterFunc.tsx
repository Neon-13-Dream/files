import ImageryLayer from "@arcgis/core/layers/ImageryLayer"
import type GraphicsLayer from "@arcgis/core/layers/GraphicsLayer"
import MosaicRule from "@arcgis/core/layers/support/MosaicRule"
import Graphic from "@arcgis/core/Graphic"
import type Extent from "@arcgis/core/geometry/Extent"
import * as projection from "@arcgis/core/geometry/projection"

interface CollectRastersOptions {
	mosaic: string | ImageryLayer;
	polygonLayer: GraphicsLayer;
	outFields: string[];
	where?: string;
	setRasterList: (items: any[]) => void;
}

// проверка валидности extent
function isValidExtent(ext: Extent) {
	return (
		ext &&
		isFinite(ext.xmin) &&
		isFinite(ext.ymin) &&
		isFinite(ext.xmax) &&
		isFinite(ext.ymax) &&
		ext.xmin < ext.xmax &&
		ext.ymin < ext.ymax
	)
}

// проекция extent в 4326
async function normalizeExtent(ext: Extent): Promise<Extent | null> {
	if (!isValidExtent(ext)) return null

	if (ext.spatialReference?.wkid === 4326) return ext

	if (!projection.isSupported()) await projection.load()

	try {
		return projection.project(ext, { wkid: 4326 }) as Extent
	} catch {
		return null
	}
}

async function getRasterThumbnail(raster: any, imageLayer: ImageryLayer) {
	if (!raster?.geometry?.extent) return null

	let extent = raster.geometry.extent
	extent = await normalizeExtent(extent)
	if (!extent) return null

	const exportUrl = `${imageLayer.url}/exportImage`
	const params = {
		f: "json",
		bbox: `${extent.xmin},${extent.ymin},${extent.xmax},${extent.ymax}`,
		bboxSR: 4326,
		size: "200,200",
		format: "png",
		imageSR: 4326,
		dpi: 96
	}

	const queryString = Object.entries(params)
		.map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
		.join("&")

	const url = `${exportUrl}?${queryString}`

	try {
		const res = await fetch(url)
		const data = await res.json()
		return data?.href || null
	} catch (err) {
		console.warn("Thumbnail skipped for OBJECTID:", raster.attributes?.OBJECTID, err)
		return null
	}
}

export async function collectRastersFromMosaic({
	mosaic,
	polygonLayer,
	outFields,
	where,
	setRasterList
}: CollectRastersOptions) {

	const imageLayer =
		typeof mosaic === "string"
			? new ImageryLayer({ url: mosaic, visible: true })
			: mosaic

	const visiblePolygons = polygonLayer.graphics.toArray().filter(g => g.visible)

	if (!visiblePolygons.length) {
		imageLayer.mosaicRule = new MosaicRule({ method: "attribute", where: "1=0" })
		setRasterList([])
		return
	}

	const rasterMap = new Map<number, any>()

	for (const graphic of visiblePolygons) {
		const query: any = {
			geometry: graphic.geometry,
			spatialRelationship: "intersects",
			returnGeometry: true,
			outFields: outFields, // ✅ Берём все поля
			where: where || "Name NOT LIKE 'Ov%'"
		}

		console.log(`(${where}) AND Name NOT LIKE 'Ov%'`)

		const result = await imageLayer.queryRasters(query)

		for (const f of result.features) {
			const id = f.attributes.OBJECTID
			if (!rasterMap.has(id)) {
				const thumbnail = await getRasterThumbnail(f, imageLayer)
				const geom = f.geometry
				if (!geom || !geom.extent) continue

				const extent = await normalizeExtent(geom.extent)
				if (!extent) continue

				const ring: number[][] = [
					[extent.xmin, extent.ymin],
					[extent.xmin, extent.ymax],
					[extent.xmax, extent.ymax],
					[extent.xmax, extent.ymin],
					[extent.xmin, extent.ymin]
				]

				rasterMap.set(id, {
					id,
					visible: true,
					attributes: f.attributes, // ✅ Сохраняем все поля
					thumbnail,
					ring,
					spatialReference: extent.spatialReference
				})
			}
		}
	}

	const rasterList = [...rasterMap.values()]

	if (rasterList.length) {
		imageLayer.mosaicRule = new MosaicRule({
			method: "attribute",
			where: `OBJECTID IN (${rasterList.map(r => r.id).join(",")})`
		})
		imageLayer.visible = true
	} else {
		imageLayer.visible = false
	}

	setRasterList(rasterList)
}
