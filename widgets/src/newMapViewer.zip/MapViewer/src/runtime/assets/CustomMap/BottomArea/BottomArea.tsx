import { React } from "jimu-core"
import MapView from "@arcgis/core/views/MapView"
import "./BottomArea.css"

import mapScaleIcon from "../../imgs/mapScale.png"
import GCSIcon from "../../imgs/GCS.png"
import MGRSIcon from "../../imgs/MGRS.png"

import { dataStruct } from "../../../cofig";

interface bottomArea {
    viewMap: MapView
    mapData: dataStruct
    onChange: (newValue: any) => void
}

export default function BottomArea(props: bottomArea) {
    const { viewMap: mapView, mapData, onChange } = props;
    const [localScale, setLocalScale] = React.useState(mapData.mapScale);


    React.useEffect(() => {
        setLocalScale(mapData.mapScale);
    }, [mapData.mapScale]);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.code !== "Enter") return;
        if (!mapView) return;

        const newScale = parseFloat(localScale.toString());
        if (isNaN(newScale)) return;

        mapView.scale = newScale;

        onChange((prev: dataStruct) => {
            return {
                ...prev,
                mapScale: newScale
            }
        });
    };

    React.useEffect(() => {
        if (!mapView) return;

        const stationaryHandler = mapView.watch("stationary", (st: boolean) => {
            if (!st) return;
            onChange((prev: dataStruct) => {
                return {
                    ...prev,
                    mapScale: mapView.scale.toFixed(0)
                }
            });
        });

        return () => {
            stationaryHandler.remove();
        };
    }, [mapView, mapData]);

    return (
        <div className="MapAttribute">
            <div className="MapAttributeTitle">Esri, © OpenStreetMap contributors, TomTom, Garmin, FAO, NOAA, USGS</div>
            <div className="MapInfo">
                <div className="CursorInfoArea">
                    <div className="CursorInfo">
                        <div className="CursorInfoIcon"><img src={GCSIcon} /></div>
                        <div className="CursorInfoStyle">{mapData.GCS.lat}°N</div>
                        <div className="CursorInfoStyle">{mapData.GCS.lon}°E</div>
                    </div>
                    <div className="CursorInfo">
                        <div className="CursorInfoIcon"><img src={MGRSIcon} /></div>
                        <div className="CursorInfoStyle">{mapData.MGRS}</div>
                    </div>
                </div>
                <div className="CursorInfo" style={{ gap: "5px" }}>
                    <div className="CursorInfoStyle">1:</div>
                    <input
                        className="mapScaleStyle"
                        type="number"
                        value={localScale}
                        onChange={(e) => setLocalScale(parseFloat(e.target.value))}
                        onKeyDown={handleKeyDown}
                    />
                    <div className="CursorInfoIcon"><img src={mapScaleIcon} /></div>
                </div>
            </div>
        </div>
    )
}