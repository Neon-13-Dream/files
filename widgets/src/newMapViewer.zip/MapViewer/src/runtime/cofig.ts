export interface dataStruct {
    GCS: {
        lon: number,
        lat: number
    }
    MGRS: string,
    scale: number,
    gList: any[],
    rList: any[]
}