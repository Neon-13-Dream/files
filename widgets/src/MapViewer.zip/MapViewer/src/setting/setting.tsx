import { React } from 'jimu-core'

export default function Setting() {
    return (
        <div>
            Hello world !!!
        </div>
    )
}