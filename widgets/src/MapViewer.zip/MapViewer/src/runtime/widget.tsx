import { React, AllWidgetProps } from "jimu-core";
import "./style.css"

import Header from "./assets/Header/Header"
import CustomMap from "./assets/CustomMap/CustomMap"
import DragAndDrop from "./assets/DragAndDrop/DragAndDrop";

export default function CustomMapWidget(props: AllWidgetProps<any>) {
    const [getData, setData] = React.useState(["none", ""])
    const [getFile, setFile] = React.useState([])
    const fetchUrl = "https://sgm.uzspace.uz/image/rest/services/Toshkent_viloyati_2025_yil/ImageServer"

    return (
        <div className="mainArea">
            <DragAndDrop
                activ={getData[0]}
                onChange={(geometries) => {
                    setFile(geometries);
                }}
            />
            <Header
                onChange={(type: string, data: any) => { setData([type, data]) }}
            />
            <CustomMap
                fetchUrl={fetchUrl}
                headerInfo={getData}
                file={getFile}
            />
        </div>
    );
}