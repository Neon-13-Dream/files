import { React } from "jimu-core";
import "./DragAndDrop.css";
import ImportIcon from "../imgs/Import.png";
import shp from "shpjs"; // npm install shpjs

interface dragAndDropProps {
    activ: string
    onChange: (geometries: any[]) => void
};

export default function DragAndDrop(props: dragAndDropProps) {
    const [isImportVisible, setImportVisible] = React.useState(false)
    const fileInputRef = React.useRef<HTMLInputElement | null>(null);

    const handleFiles = async (files: FileList | null) => {
        if (!files || files.length === 0) return;

        const file = files[0];
        const maxSize = 15 * 1024 * 1024; // 15MB

        if (file.size > maxSize) {
            alert("Файл слишком большой (макс. 15 МБ)");
            return;
        }

        const ext = file.name.split(".").pop()?.toLowerCase();
        if (!ext || !["kml", "zip", "geojson"].includes(ext)) {
            alert("Неподдерживаемый формат. Разрешены KML, SHP (zip), GeoJSON");
            return;
        }

        try {
            let geometries: any[] = [];

            if (ext === "zip") { // ZIP с SHP
                const arrayBuffer = await file.arrayBuffer();
                const geojson = await shp(arrayBuffer); // shpjs распарсит zip
                if (geojson.features) {
                    geometries = geojson.features.map(f => f.geometry);
                } else if (geojson.type && geojson.coordinates) {
                    geometries = [geojson];
                } else {
                    alert("Файл не содержит геометрий");
                    return;
                }
            } else if (ext === "geojson") {
                const text = await file.text();
                const geojson = JSON.parse(text);
                geometries = geojson.features ? geojson.features.map((f: any) => f.geometry) : [geojson];
            } else if (ext === "kml") {
                const text = await file.text();
                geometries = parseKML(text);
            }

            props.onChange(geometries);
        } catch (err) {
            console.error(err);
            alert("Ошибка при обработке файла");
        }

        setImportVisible(false)
    };

    const parseKML = (kmlText: string) => {
        const parser = new DOMParser();
        const kml = parser.parseFromString(kmlText, "text/xml");
        const placemarks = kml.getElementsByTagName("Placemark");
        const geometries: any[] = [];

        for (let i = 0; i < placemarks.length; i++) {
            const placemark = placemarks[i];

            // Polygon
            const polygon = placemark.getElementsByTagName("Polygon")[0];
            if (polygon) {
                const coords = polygon.getElementsByTagName("coordinates")[0]?.textContent?.trim();
                if (coords) {
                    const points = coords.split(/\s+/).map(c => {
                        const [lon, lat] = c.split(",").map(Number);
                        return [lon, lat];
                    });
                    geometries.push({ type: "Polygon", coordinates: [points] });
                }
            }

            // Point
            const point = placemark.getElementsByTagName("Point")[0];
            if (point) {
                const coords = point.getElementsByTagName("coordinates")[0]?.textContent?.trim();
                if (coords) {
                    const [lon, lat] = coords.split(",").map(Number);
                    geometries.push({ type: "Point", coordinates: [lon, lat] });
                }
            }

            // LineString
            const line = placemark.getElementsByTagName("LineString")[0];
            if (line) {
                const coords = line.getElementsByTagName("coordinates")[0]?.textContent?.trim();
                if (coords) {
                    const points = coords.split(/\s+/).map(c => {
                        const [lon, lat] = c.split(",").map(Number);
                        return [lon, lat];
                    });
                    geometries.push({ type: "LineString", coordinates: points });
                }
            }
        }

        return geometries;
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        handleFiles(e.dataTransfer.files);
    };

    const handleClick = () => {
        fileInputRef.current?.click();
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        handleFiles(e.target.files);
    };

    React.useEffect(() => {
        setImportVisible(props.activ === "Import")
    }, [props])

    return isImportVisible ? (
        <div
            className="DragAndDropArea"
            onDragOver={e => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => setImportVisible(false)} // клик вне блока закрывает
        >
            <div
                className="DragAndDropBlock"
                onClick={e => e.stopPropagation()} // останавливаем всплытие, клик по блоку не закроет окно
            >
                <div className="DragAndDropHeader">
                    <div className="DragAndDropTitle">Hudud faylini yuklang</div>
                </div>
                <div className="DragAndDropDesc" onClick={handleClick}>
                    <input
                        type="file"
                        ref={fileInputRef}
                        style={{ display: "none" }}
                        onChange={handleChange}
                    />
                    <div className="DragAndDropIcon">
                        <img src={ImportIcon} />
                    </div>
                    <div className="DragAndDropInfo">
                        <span>Yuklash uchun bosing</span> yoki faylni shu yerga tashlang
                    </div>
                    <div className="DragAndDropInfo">
                        15 MB gacha bo‘lgan KML, SHP (zip) yoki GeoJSON fayl
                    </div>
                </div>
            </div>
        </div>
    ) : null;
}
