import { React } from "jimu-core"
import type MapView from "@arcgis/core/views/MapView"
import "./RightArea.css"

import LayersIcon from "../../imgs/Layers.png"
import RulerIcon from "../../imgs/Ruler.png"
import MeasureAreaIcon from "../../imgs/MeasureArea.png"
import PlusIcon from "../../imgs/Plus.png"
import MinusIcon from "../../imgs/Minus.png"

interface rightAreaProps {
    map: MapView
    onChange: (type: string) => void
}

const baseMaps = {
    vector: [
        "streets-vector",
        "streets-night-vector",
        "streets-navigation-vector",
        "topo-vector",
        "streets-relief-vector",
        "dark-gray-vector",
        "dark-gray"
    ],
    raster: [
        "satellite",
        "hybrid",
        "terrain",
        "topo",
        "oceans"
    ]
}

export default function RightArea({ map, onChange }: rightAreaProps) {
    const [showBasemaps, setShowBasemaps] = React.useState(false)

    if (!map) return null

    const zoomIn = () => {
        map.goTo({ zoom: Math.min(map.zoom + 1, 20) }, { duration: 500 })
    }

    const zoomOut = () => {
        map.goTo({ zoom: Math.max(map.zoom - 1, 1) }, { duration: 500 })
    }

    const changeBasemap = (id: string) => {
        map.map.basemap = id
        setShowBasemaps(false)
    }

    return (
        <div className="RightArea">
            <div className="RightBtnArea layers-wrapper">
                {showBasemaps && (
                    <div className="BasemapPopup">
                        <div className="BasemapHeader">
                            Базовые карты
                        </div>

                        <div className="BasemapGroup">
                            <div className="BasemapGroupTitle">Векторные</div>
                            {baseMaps.vector.map(bm => (
                                <div
                                    key={bm}
                                    className={`BasemapItem ${map.map.basemap?.id === bm ? "active" : ""}`}
                                    onClick={() => changeBasemap(bm)}
                                >
                                    {bm}
                                </div>
                            ))}
                        </div>

                        <div className="BasemapGroup">
                            <div className="BasemapGroupTitle">Растровые</div>
                            {baseMaps.raster.map(bm => (
                                <div
                                    key={bm}
                                    className={`BasemapItem ${map.map.basemap?.id === bm ? "active" : ""}`}
                                    onClick={() => changeBasemap(bm)}
                                >
                                    {bm}
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                <div
                    className="RightAreaBtn"
                    onClick={() => setShowBasemaps((v: any) => !v)}
                >
                    <img src={LayersIcon} />
                </div>
            </div>

            <div className="RightBtnArea">
                <div className="RightAreaBtn" onClick={() => onChange("line")}><img src={RulerIcon} /></div>
                <div className="RightAreaBtn" onClick={() => onChange("area")}><img src={MeasureAreaIcon} /></div>
            </div>

            <div className="RightBtnArea">
                <div className="RightAreaBtn" onClick={zoomIn}><img src={PlusIcon} /></div>
                <div className="RightAreaBtn" onClick={zoomOut}><img src={MinusIcon} /></div>
            </div>
        </div>
    )
}
