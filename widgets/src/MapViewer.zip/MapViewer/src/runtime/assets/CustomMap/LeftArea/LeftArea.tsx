import { React } from "jimu-core"
import "./LeftArea.css"

import ZoomToIcon from "../../imgs/ZoomTo.png"
import DeleteIcon from "../../imgs/Delete.png"
import CheckIcon from "../../imgs/Check.png"
import GeometryEmptyIcon from "../../imgs/GeometryEmpty.png"
import RasterEmptyIcon from "../../imgs/RasterEmpty.png"
import CloudIcon from "../../imgs/Cloud.png"
import AngleIcon from "../../imgs/Angle.png"
import SettingIcon from "../../imgs/Setting.png"
import SettingActivIcon from "../../imgs/SettingActiv.png"

import Popup from "../Popup/Popup"

const LeftAreaTypes = [
    "Hududlar",
    "Tasvirlar"
] as const
type LeftAreaType = typeof LeftAreaTypes[number];

interface leftAreaProps {
    geomList: any[],
    rasterList: any[],
    onChange: (type: string, index: any) => void
}

function LeftArea(props: leftAreaProps) {
    const [getAction, setAction] = React.useState<{ type: string, data: any, index: number }>({
        type: "none",
        data: "",
        index: -1
    })
    const [getSelectCount, setSelectCount] = React.useState({
        count: 0,
        select: 0
    })
    const [getType, setType] = React.useState<LeftAreaType>(LeftAreaTypes[0])
    const ListTitels: Record<LeftAreaType, string> = {
        "Hududlar": "Sizning hududlaringiz roʻyxati",
        "Tasvirlar": "Natijalar"
    }

    const popupType = (type: string, data: any, index: number) => {
        switch (type) {
            case "info":
                if (data.OBJECTID !== getAction.index) {
                    setAction({ type: type, data: data, index: index })
                }
                else {
                    setAction({ type: "none", data: "", index: -1 })
                }
                break;

            case "filter":
                if (type !== getAction.type) {
                    setAction({ type: type, data: "", index: -2 })
                }
                else {
                    setAction({ type: "none", data: "", index: -1 })
                }
                break;

            default:
                setAction({ type: "none", data: "", index: -1 })
                break;
        }
    }

    React.useEffect(() => {
        if (getType === "Hududlar") {
            setSelectCount({
                count: props.geomList.length,
                select: props.geomList.filter((item: any) => item.visible).length
            })
        }
        else if (getType === "Tasvirlar") {
            setSelectCount({
                count: props.rasterList.length,
                select: props.rasterList.filter((item: any) => item.visible).length
            })
        }
    }, [getType, props])

    return (
        <div className="LeftArea">
            <div className="LeftAreaHeader">
                <div className="LeaftAreaTypes">
                    {LeftAreaTypes.map((item: LeftAreaType) => (
                        <div className={`LeaftAreaType ${getType === item ? 'activ' : ''}`} onClick={() => { setType(item) }}>{item}</div>
                    ))}
                </div>
                <div className="HeaderBtn" onClick={() => { popupType("filter", "", -2) }}>
                    <img src={getAction.type === "filter" ? SettingActivIcon : SettingIcon} />
                </div>
            </div>
            <div className="LeftAreaListInfo">
                <div className="ListAreaTitle">{ListTitels[getType]}</div>
                {getSelectCount.count && <div className="ListAreaContent">
                    <div className="ContentSelected">Tanlangan: {getSelectCount.select}/{getSelectCount.count}</div>
                    <div className="ContentBtns">
                        <div
                            className={`ContentBtn ${getSelectCount.select > 0 ? 'activ' : ''}`}
                            onClick={() => {
                                if (getSelectCount.select > 0) {
                                    if (getType === "Hududlar") props.onChange("gHideAll", -1)
                                    if (getType === "Tasvirlar") props.onChange("rHideAll", -1)
                                }
                            }}
                        >
                            Bekor qilish
                        </div>
                        <div
                            className={`ContentBtn ${getSelectCount.select < getSelectCount.count ? 'activ' : ''}`}
                            onClick={() => {
                                if (getSelectCount.select < getSelectCount.count) {
                                    if (getType === "Hududlar") props.onChange("gShowAll", -1)
                                    if (getType === "Tasvirlar") props.onChange("rShowAll", -1)
                                }
                            }}
                        >
                            Barchasini belgilash
                        </div>
                    </div>
                </div>}
            </div>
            <div className="LeftAreaList">
                {getType === "Hududlar" && props.geomList.length > 0 && props.geomList.map((item: any, index: number) => (
                    <div
                        className="LeftAreaListItem Hududlar"
                        onMouseEnter={() => props.onChange("gHover", index)}
                        onMouseLeave={() => props.onChange("gUnhover", index)}
                    >
                        <div className="ItemTopContent">
                            <div className={`ItemCheckBox ${item.visible ? 'activ' : ''}`} onClick={() => { props.onChange("gToggel", index) }}>
                                {item.visible && <img src={CheckIcon} />}
                            </div>
                            <div className="ItemName">{item.name}</div>
                        </div>
                        <div className="ItemBottomContent">
                            <div className="ItemInfo">Qamrov: {item.area}km<sup>2</sup></div>
                            <div className="ItemBtns">
                                <div className="ItemBtn" onClick={() => { props.onChange("gZoom", index) }}><img src={ZoomToIcon} /></div>
                                <div className="ItemBtn" onClick={() => { props.onChange("gDelete", index) }}><img src={DeleteIcon} /></div>
                            </div>
                        </div>
                    </div>
                ))}
                {getType === "Tasvirlar" && props.rasterList.length > 0 && props.rasterList.map((item: any, index: number) => (
                    <div className={`LeftAreaListItem Tasvirlar ${item.attributes.OBJECTID === getAction.index ? 'activ' : ''}`}
                        onMouseEnter={() => props.onChange("rHover", index)}
                        onMouseLeave={() => props.onChange("rUnhover", index)}
                        onClick={() => { popupType("info", item.attributes, item.id) }}
                    >
                        <div className="ItemIcon">
                            <img src={item.thumbnail} />
                            <div className={`ItemCheckBox ${item.visible ? 'activ' : ''}`} onClick={() => { props.onChange("rToggel", index) }}>
                                {item.visible && <img src={CheckIcon} />}
                            </div>
                        </div>
                        <div className="ItemRightContent">
                            <div className="ItemName">Tasvir ID: {item.attributes.Catalog_ID}</div>
                            <div className="ItemName">
                                {item.attributes.Sana ? new Date(item.attributes.Sana).toLocaleDateString('ru-RU') : ''}
                            </div>
                            <div className="ItemRightInfo">
                                <div className="InfoArea">
                                    <img src={CloudIcon} />{item.attributes.Bulut_qop}%
                                </div>
                                <div className="InfoArea">
                                    <img src={AngleIcon} />{item.attributes.Ogish_bur}°
                                </div>
                                <div className="InfoArea">
                                    <img src={AngleIcon} />{item.attributes.Sensor}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
                {!getSelectCount.count && <div className="EmptyArea">
                    <div className="EmptyIcon">
                        <img src={
                            getType === "Hududlar" ? GeometryEmptyIcon : RasterEmptyIcon
                        } />
                    </div>
                    <div className="EmptyDesc">
                        {getType === "Hududlar" ? "Mavjud tasvirlarni ko‘rish uchun iltimos, hudud qo‘shing" : "Kunlik tasvirlar katalogini ko‘rish mumkin bo‘lgan joyni toping"}
                    </div>
                </div>}
            </div>

            <Popup
                actiom={getAction}
                onChange={( value: string ) => { props.onChange( "where", value ) }}
            />
        </div>
    )
}

export default React.memo(LeftArea)