/** @jsx jsx */
import {
    jsx, Immutable,
    React, DataSourceTypes, DataSourceManager
} from 'jimu-core'
import { Select } from 'jimu-ui'
import type { AllWidgetSettingProps } from 'jimu-for-builder'
import { DataSourceSelector } from 'jimu-ui/advanced/data-source-selector'
import { defaultTitels, defaultStyle } from '../config'

export default function Setting(props: AllWidgetSettingProps<any>) {
    const [fields, setFields] = React.useState<any[]>([])
    const [statistic, setStatistic] = React.useState<any>("COUNT")
    const [selectedField, setSelectedField] = React.useState<any>("FIELD")

    React.useEffect(() => {
        if (props.config.fields && props.config.fields.length > 0) {
            setFields(props.config.fields)
        }
    }, [props.config.fields])

    const saveHandler = (useDataSources: any[]) => {
        props.onSettingChange({
            id: props.id,
            useDataSources
        })

        const dsId = useDataSources?.[0]?.dataSourceId
        if (!dsId) return

        const ds = DataSourceManager.getInstance().getDataSource(dsId)
        if (!ds) return

        const schema = ds.getSchema()
        if (!schema?.fields) return

        var fieldsObj: any[] = []
        Object.values(schema.fields).forEach((item: any, index: number) => {
            if (item.type == "NUMBER") fieldsObj.push(item.name)
            }
        )
        console.log("....")
        console.log(schema.fields);

        setFields(fieldsObj)

        props.onSettingChange({
            id: props.id,
            config: {
                ...props.config,
                fields: fieldsObj
            }
        })
    }

    const handleChange = (e: any, key: string) => {
        props.onSettingChange({
            id: props.id,
            config: {
                ...props.config,
                [key]: e
            }
        })
    }



    return (
        <div style={{
            padding: "15px"
        }}>
            <DataSourceSelector
                mustUseDataSource
                types={Immutable([DataSourceTypes.FeatureLayer])}
                useDataSources={props.useDataSources}
                onChange={saveHandler}
                widgetId={props.id}
            />

            <h4 style={{ marginTop: '10px' }}>Statistic</h4>
            <div
                style={{
                    width: 200
                }}
            >
                <Select
                    appendToBody
                    onChange={(event: any, newVal: any) => {
                        setStatistic(newVal.props.value)
                        handleChange(newVal.props.value, "stat")
                    }}
                    onClick={() => { }}
                    placeholder="Select a destination"
                    size="default"
                    value={statistic}
                >
                    <Option value="COUNT">
                        Count
                    </Option>
                    <Option value="AVG">
                        AVG
                    </Option>
                    <Option value="SUM">
                        SUM
                    </Option>
                    <Option value="MAX">
                        MAX
                    </Option>
                    <Option value="MIN">
                        MIN
                    </Option>
                </Select>
            </div>

            <h4 style={{ marginTop: '10px' }}>Field</h4>
            <div
                style={{
                    width: 200
                }}
            >
                <Select
                    appendToBody
                    onChange={(event: any, newVal: any) => {
                        setSelectedField(newVal.props.value)
                        handleChange(newVal.props.value, "field")
                    }}
                    onClick={() => { }}
                    placeholder="Select a destination"
                    size="default"
                    value={selectedField}
                >
                    {fields.map((item: string) => (
                        <Option value={`${item}`}>
                            {item}
                        </Option>
                    ))}

                </Select>
            </div>

            <h4 style={{ marginTop: '10px' }}>Количество</h4>
            <input
                style={{
                    marginTop: "-10px",
                    width: "100%",
                    height: "30px"
                }}
                type="text"
                value={props.config.buttonName || "DefaultName "}
                onChange={(e: any) => handleChange(e.target.value, "buttonName")}

            />
        </div>
    )
}
