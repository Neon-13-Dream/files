import {
    React, type AllWidgetProps,
    DataSourceComponent,
    type FeatureDataRecord
} from "jimu-core"
import { Select } from 'jimu-ui'
import Query from "@arcgis/core/rest/support/Query"

export default function Widget(props: AllWidgetProps<any>) {
    const useDataSource = props.useDataSources?.[0]


    const updateData = (main: any, count: number) => {
        main.count += count
    }

    const testRef = React.useRef()
    const [getCount, setCount] = React.useState(0)

    React.useEffect(() => {
        console.log(props.config);
        if (!testRef.current) return

        testRef.current.query({
            where: "1=1",
            outFields: ['*'],
            // groupByFieldsForStatistics: [`${props.config.field}`],
            returnGeometry: false,
            outStatistics: [
                {
                    statisticType: `${props.config.stat}`,
                    onStatisticField: `${props.config.field}`,
                    outStatisticFieldName: 'maydon_count'
                },
            ],
        }).then((result: any) => {
            const recs = result.records as FeatureDataRecord[]

            setCount(recs.map((r: any) => ({ ...r.getData() }))[0]["maydon_count"]);
        })

    }, [props.config])

    // const dataSourceCreated = async (ds: any) => {
    //     const query = new Query({
    //         where: "1=1"
    //     })
    //     const data = (await ds.queryCount(query))
    //     console.log(await ds.queryCount(query));
    //     setCount(data);
    // }


    const dataSourceCreated = (ds: any) => {
        try {
            ds.query({
                where: "1=1",
                outFields: ['*'],
                // groupByFieldsForStatistics: [`${props.config.field}`],
                returnGeometry: false,
                outStatistics: [
                    {
                        statisticType: `${props.config.stat}`,
                        onStatisticField: `${props.config.field}`,
                        outStatisticFieldName: 'maydon_count'
                    },
                ],
            }).then((result: any) => {
                const recs = result.records as FeatureDataRecord[]

                setCount(recs.map((r: any) => ({ ...r.getData() }))[0]["maydon_count"]);
            })
        } catch (error) {

        }

        testRef.current = ds;
    }

    return (
        <div style={{}}>
            <DataSourceComponent
                useDataSource={useDataSource}
                onDataSourceCreated={dataSourceCreated}
            />
            <div>{props.config.buttonName} {getCount}</div>
        </div>
    )
}